fn main() {
    loop {
        println!("Welcome, please select an option to begin");
        println!("F for Fahrenheit\nC for Celcius\nE for Exit");

        let choice = read_line().to_uppercase();
        let choice = UserChoice::new(&choice);

        match choice {
            Ok(choice) => match choice {
                UserChoice::Fahrenheit => {
                    println!("Please give me a temperature in Fahrenheit");

                    let f = read_line();

                    let f: f64 = f.parse().unwrap();
                    
                    match f_to_c(f) {
                        Some(c) => println!("{:.2} Fahrenheit is {:.2} Celsius", f, c),
                        None => println!("Cannot go lower than absolute zero"),
                    }
                }
                UserChoice::Celcius => {
                    println!("Please give me a temperature in Celcius");

                    let c = read_line();

                    let c: f64 = c.parse().unwrap();

                    match c_to_f(c) {
                        Some(f) => println!("{:.2} Celcius is {:.2} Fahrenheit", c, f),
                        None => println!("Cannot go lower than absolute zero"),
                    }
                }
                UserChoice::Exit => {
                    break;
                }
            },
            Err(choice) => println!("{} is Invalid", choice),
        }
    }
}

fn c_to_f(c: f64) -> Option<f64> {
    if c >= -273.15 {
        Some((c * (9. / 5.)) + 32.)
    } else {
        None
    }
}

fn f_to_c(f: f64) -> Option<f64> {
    if f >= -459.67 {
        Some((f - 32.) * (5. / 9.))
    } else {
        None
    }
}

fn read_line() -> String {
    let stdin = std::io::stdin();

    let mut choice = String::new();
    stdin.read_line(&mut choice).unwrap();

    return choice.trim().to_owned();
}

enum UserChoice {
    Fahrenheit,
    Celcius,
    Exit,
}

impl UserChoice {
    fn new(choice: &str) -> Result<UserChoice, &str> {
        match choice {
            "F" => Ok(UserChoice::Fahrenheit),
            "C" => Ok(UserChoice::Celcius),
            "E" => Ok(UserChoice::Exit),
            _ => Err(choice),
        }
    }
}
