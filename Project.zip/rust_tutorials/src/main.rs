#![allow(dead_code, unused_variables)]

fn main() {
    color_backtrace::install();

    // allocated on the stack
    // stack variable
    // stack memory
    let var1 = 5;

    let mut var2 = Vec::new(); // 5000
                               // this is an optimization
    var2.reserve(4);
    // stuck on the heap
    var2.push(2); // memory adress 5000 => 2
    var2.push(3); // memory adress 5001 => 3
    var2.push(4); // memory adress 5002 => 4
    var2.push(5); // memory adress 5003 => 5

    const VAR3: i32 = (5 + 5) / 5 * 2;

    let var4: String = String::from("blubb");

    fun1(&var4);

    let var5: String = fun2();

    let var6: [i32; 5] = [0, 1, 2, 3, 4];

    let mut var7 = Struct { field1: 5 };
    var7.field1 = 6;
    println!("{}", var7.field1);

    let var8 = Struct::method();

    let mut var9 = Struct::new(10);

    println!("{}", var9.field1());

    var9.set_field1(9);

    var9.consume();

    // can't use after move
    // println!("{}", var9.field1());

    let var10: Enum1 = Enum1::Variant1;
    fun3(var10);

    let var11 = Enum2::Variant1(5);
    let var12 = Enum2::Variant2(String::from("blubb"));

    // panics
    // fun7();

    let var13 = vec![0, 1, 2, 3];
    println!("{:?}", var13.get(4));

    let mut var14 = Some(5);

    if let Some(value) = var14 {
        println!("{}", value);
    }

    var14 = None;

    if let None = var14 {
        println!("No value found");
    }

    let mut var15 = Some(5);
    println!("{}", var15.unwrap());

    var15 = None;
    println!("{}", var15.unwrap_or(5));
}

fn fun1(par1: &str) {
    println!("{}{}{}", par1, par1, par1);
}

fn fun2() -> String {
    let var1: &str = "blubb";
    let var2: String = var1.to_owned();
    return var2;
}

fn fun3(par1: Enum1) {
    match par1 {
        Enum1::Variant1 => {
            println!("This enum is `Variant1`");
        }
        Enum1::Variant2 => {
            println!("This enum is `Variant2`");
        }
    }

    if let Enum1::Variant1 = par1 {
        println!("This enum is `Variant1`");
    } else if let Enum1::Variant2 = par1 {
        println!("This enum is `Variant2`");
    }
}

fn fun4(par1: Enum1) -> i32 {
    if let Enum1::Variant1 = par1 {
        2
    } else if let Enum1::Variant2 = par1 {
        3
    } else {
        4
    }
}

fn fun6(par1: Enum2) {
    match par1 {
        Enum2::Variant1(var1) => {
            println!("This enum is `Variant1` with the value of: {}", var1);
        }
        Enum2::Variant2(ref var1) => {
            println!("This enum is `Variant2` with the value of: {}", var1);
        }
    }

    if let Enum2::Variant1(var1) = par1 {
        println!("This enum is `Variant1` {}", var1);
    } else if let Enum2::Variant2(var1) = par1 {
        println!("This enum is `Variant2` {}", var1);
    }
}

fn fun7() {
    panic!("blablabla");
}

struct Struct {
    field1: i32,
}

impl Struct {
    // Self => Struct
    // self => current instantiation

    // static method
    fn method() -> i32 {
        7
    }

    fn new(field1: i32) -> Self {
        Self { field1 }
    }

    /// Return whats inside of `field1`.
    fn field1(&self) -> i32 {
        self.field1
    }

    fn set_field1(&mut self, new_field1: i32) {
        self.field1 = new_field1;
    }

    fn consume(self) {
        println!("{}", self.field1)
    }
}

enum Enum1 {
    Variant1,
    Variant2,
}

enum Enum2 {
    Variant1(i32),
    Variant2(String),
}
