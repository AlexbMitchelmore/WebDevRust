fn main() {
    let num = 7;

    if num < 5 {
        println!("Condition was true");
    } else {
        println!("Condition was false");
    }

    let num2 = 6;

    if num2 % 4 == 0{
        println!("Number is divisible by 4");
    } else if num2 % 3 == 0{
        println!("Number is divisible by 3");
    } else if num2 % 4 == 0{
        println!("Number is divisible by 2");
    } else{
        println!("Number is not divisible by 4, 3, or 2");
    }

    let condition = true;
    let number = if condition { 5 } else { 6 };

    println!("The number is: {}", number);

    //infinite loop ctrl+C to stop
    // loop {
    //     println!("Again!");
    // }

    let mut counter = 0;

    let result = loop{
        counter += 1;

        if counter == 10 {
            break counter * 2;
        }
    };
        
    println!("The result is {}", result);    

    let mut number3 = 3;

    while number3 != 0{
        println!("{}!", number3);
        number3 -= 1;
    }
    println!("LIFT OFF!!!!!");

    let a = [10, 20, 30, 40, 50];
    let mut index = 0;

    while index < 5 {
        println!("the value is: {}", a[index]);

        index += 1;
    }
    for element in a.iter() {
        println!("the value is: {}", element);
    }

    for number2 in (1..4).rev() {
        println!("{}!", number2);
    }
    println!("LIFTOFF!!!");
}
