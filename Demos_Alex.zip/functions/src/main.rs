fn main() {
    println!("Hello, world!");

    another_function();
    another_function2(5);
    another_function3(1, 2);

    //let x = (let y = 6);

    let x = five();

    println!("The value is: {}", x);
    println!("The value is: {}", five());
    another_function2(five());

    let num = plus_one(5);
    println!("The value of num is: {}", num);

}

fn another_function(){
    println!("Another function");
}

fn another_function2(x: i32){
    println!("The value of x is: {}", x);
}

fn another_function3(x: i32, y: i32){
    println!("The values are: {} and {}, together they make {}", x, y, x + y);
}

fn five() -> i32{
    5
}

fn plus_one(x: i32) -> i32{
    x + 1
}

